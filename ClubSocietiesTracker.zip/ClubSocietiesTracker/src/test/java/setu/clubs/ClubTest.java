package setu.clubs;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ClubTest {

    @Test
    public void testAddMemberToClubSuccessfully() {
        Club club = new Club("Hiking Club", 25.0);
        boolean result = club.addMember("AB123456");
        assertTrue(result, "Should add member to club");
        assertEquals(1, club.getMembers().size());
        assertEquals("AB123456", club.getMembers().get(0));
    }

    @Test
    public void testCannotAddSameMemberTwice() {
        Club club = new Club("Drama Society", 30.0);
        club.addMember("CD789012");
        boolean result = club.addMember("CD789012");
        assertFalse(result, "Shouldn't add same member twice");
    }

    @Test
    public void testCannotAddMemberWithNullId() {
        Club club = new Club("Music Club", 20.0);
        boolean result = club.addMember(null);
        assertFalse(result, "Cannot add member with null ID");
    }

    @Test
    public void testRemoveMemberFromClub() {
        Club club = new Club("Art Club", 15.0);
        club.addMember("EF345678");
        boolean result = club.removeMember("EF345678");
        assertTrue(result, "Should remove member from club");
        assertEquals(0, club.getMembers().size());
    }

    @Test
    public void testClubHasMaximumFiftyMembers() {
        Club club = new Club("Popular Club", 10.0);
        // 50 members
        for (int i = 0; i < 50; i++) {
            club.addMember("ID" + String.format("%06d", i));
        }
        // trying to add 51
        boolean result = club.addMember("OVERFLOW");
        assertFalse(result, "Club shouldn't exceed 50 members");
    }
}