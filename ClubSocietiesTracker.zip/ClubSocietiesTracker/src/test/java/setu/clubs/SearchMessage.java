package setu.clubs;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SearchMessage {

    // find club
    @Test
    public void testFindClubByName() {
        Club football = new Club("Football Club", 50.0);
        Club chess = new Club("Chess Club", 20.0);
        Club hiking = new Club("Hiking Club", 15.0);

        Club[] clubs = {football, chess, hiking};

        Club found = null;
        for (Club club : clubs) {
            if (club.getName().equals("Chess Club")) {
                found = club;
                break;
            }
        }

        assertNotNull(found, "Should find Chess Club");
        assertEquals("Chess Club", found.getName());
    }

    @Test
    public void testFindClubThatDoesNotExist() {
        Club football = new Club("Football Club", 50.0);
        Club[] clubs = {football};

        Club found = null;
        for (Club club : clubs) {
            if (club.getName().equals("Rugby Club")) {
                found = club;
                break;
            }
        }
        assertNull(found, "Shouldn't find non-existent club");
    }

    // message club
    @Test
    public void testSendMessageToClub() {
        Club club = new Club("Debate Club", 10.0);
        String message = "When is the next meeting?";

        // simulation of sending message
        boolean messageSent = (message != null && !message.isEmpty() && club != null);

        assertTrue(messageSent, "Should be able to send message to club");
    }

    @Test
    public void testCannotSendEmptyMessageToClub() {
        Club club = new Club("Book Club", 5.0);
        String message = "";

        boolean messageSent = (message != null && !message.isEmpty() && club != null);

        assertFalse(messageSent, "Cannot send empty message");
    }

    @Test
    public void testCannotSendMessageToNullClub() {
        Club club = null;
        String message = "Hello!";

        boolean messageSent = (message != null && !message.isEmpty() && club != null);

        assertFalse(messageSent, "Cannot send message to null club");
    }
}