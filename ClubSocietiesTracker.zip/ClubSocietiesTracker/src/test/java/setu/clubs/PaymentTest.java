package setu.clubs;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PaymentTest {

    @Test
    public void testValidPaymentShouldBeSuccessful() {
        Payment payment = new Payment(50.0, "AB123456");
        boolean result = payment.processPayment();
        assertTrue(result, "Valid payment should be successful");
        assertTrue(payment.isSuccessful());
    }

    @Test
    public void testPaymentWithZeroAmountShouldFail() {
        Payment payment = new Payment(0, "AB123456");
        boolean result = payment.processPayment();
        assertFalse(result, "Payment with zero amount should fail");
        assertFalse(payment.isSuccessful());
    }

    @Test
    public void testPaymentWithInvalidStudentIdShouldFail() {
        Payment payment = new Payment(50.0, "invalid");
        boolean result = payment.processPayment();
        assertFalse(result, "Payment with invalid student ID should fail");
    }

    @Test
    public void testPaymentWithNullStudentIdShouldFail() {
        Payment payment = new Payment(50.0, null);
        boolean result = payment.processPayment();
        assertFalse(result, "Payment with null student ID should fail");
    }

    @Test
    public void testPaymentHasDate() {
        Payment payment = new Payment(25.0, "CD789012");
        assertNotNull(payment.getDate(), "Payment should have a date");
    }
}