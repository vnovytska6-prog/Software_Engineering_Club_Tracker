package setu.clubs;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StudentTest {

    @Test
    public void testStudentCanJoinClubSuccessfully() {
        Student student = new Student("Anna Murphy", "AB123456");
        boolean result = student.joinClub("Football Club");
        assertTrue(result, "Student should be able to join a club");
        assertEquals(1, student.getClubs().size());
        assertEquals("Football Club", student.getClubs().get(0));
    }

    @Test
    public void testStudentCannotJoinSameClubTwice() {
        Student student = new Student("John Doe", "CD789012");
        student.joinClub("Chess Club");
        boolean result = student.joinClub("Chess Club");
        assertFalse(result, "Student shouldn't join same club twice");
    }

    @Test
    public void testStudentCannotJoinClubWithNullName() {
        Student student = new Student("Mary Smith", "EF345678");
        boolean result = student.joinClub(null);
        assertFalse(result, "Cannot join club with null name");
    }

    @Test
    public void testStudentJoinEventWhenSpaceAvailable() {
        Student student = new Student("Peter Jones", "GH901234");
        Event event = new Event("Main Hall", "3:00 PM", 10);
        boolean result = student.joinEvent(event);
        assertTrue(result, "Student should join event with space");
    }

    @Test
    public void testStudentCannotJoinFullEvent() {
        Student student1 = new Student("Student1", "AB111111");
        Student student2 = new Student("Student2", "AB222222");
        Event event = new Event("Small Room", "2:00 PM", 1);

        student1.joinEvent(event);
        boolean result = student2.joinEvent(event);

        assertFalse(result, "Student cannot join full event");
    }

    @Test
    public void testStudentCannotJoinNullEvent() {
        Student student = new Student("Test User", "XX999999");
        boolean result = student.joinEvent(null);
        assertFalse(result, "Cannot join null event");
    }
}