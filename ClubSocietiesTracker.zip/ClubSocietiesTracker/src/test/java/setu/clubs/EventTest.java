package setu.clubs;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EventTest {

    @Test
    public void testEventHasCorrectLocationAndTime() {
        Event event = new Event("Sports Hall", "6:00 PM", 20);
        assertEquals("Sports Hall", event.getLocation());
        assertEquals("6:00 PM", event.getTime());
    }

    @Test
    public void testAddStudentToEventWhenSpaceAvailable() {
        Event event = new Event("Meeting Room", "2:00 PM", 5);
        Student student = new Student("John", "AB123456");
        boolean result = event.addStudent(student);
        assertTrue(result, "Should add student to event");
        assertEquals(1, event.getCurrentStudents());
    }

    @Test
    public void testCannotAddStudentToFullEvent() {
        Event event = new Event("Small Room", "1:00 PM", 1);
        Student student1 = new Student("Student1", "AB111111");
        Student student2 = new Student("Student2", "AB222222");

        event.addStudent(student1);
        boolean result = event.addStudent(student2);

        assertFalse(result, "Cannot add student to full event");
        assertEquals(1, event.getCurrentStudents());
    }

    @Test
    public void testCannotAddNullStudentToEvent() {
        Event event = new Event("Theatre", "7:00 PM", 10);
        boolean result = event.addStudent(null);
        assertFalse(result, "Cannot add null student to event");
    }
}