package setu.clubs;

import java.time.LocalDate;

public class Payment {
    private double amount;
    private LocalDate date;
    private String studentId;
    private boolean successful;

    public Payment(double amount, String studentId) {
        this.amount = amount;
        this.studentId = studentId;
        this.date = LocalDate.now();
        this.successful = false;
    }

    public boolean processPayment() {
        if (amount <= 0) return false;
        if (studentId == null || studentId.length() != 8) return false;
        if (amount > 500) return false;  // payment limit
        this.successful = true;
        return true;
    }

    public double getAmount() { return amount; }
    public LocalDate getDate() { return date; }
    public boolean isSuccessful() { return successful; }
}