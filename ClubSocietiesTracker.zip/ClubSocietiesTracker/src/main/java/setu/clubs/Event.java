package setu.clubs;

import java.util.ArrayList;
import java.util.List;

public class Event {
    private String location;
    private String time;
    private List<Student> students;
    private int maxStudents;

    public Event(String location, String time, int maxStudents) {
        this.location = location;
        this.time = time;
        this.maxStudents = maxStudents;
        this.students = new ArrayList<>();
    }

    public boolean addStudent(Student student) {
        if (students.size() >= maxStudents) return false;
        if (student == null) return false;
        students.add(student);
        return true;
    }

    public String getLocation() { return location; }
    public String getTime() { return time; }
    public int getCurrentStudents() { return students.size(); }
    public int getMaxStudents() { return maxStudents; }
}