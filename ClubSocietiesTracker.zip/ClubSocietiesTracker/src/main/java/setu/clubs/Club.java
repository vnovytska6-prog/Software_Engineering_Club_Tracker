package setu.clubs;

import java.util.ArrayList;
import java.util.List;

public class Club {
    private String name;
    private List<String> members;
    private double membershipFee;

    public Club(String name, double membershipFee) {
        this.name = name;
        this.membershipFee = membershipFee;
        this.members = new ArrayList<>();
    }

    // addMember
    public boolean addMember(String studentId) {
        if (studentId == null || studentId.isEmpty()) return false;
        if (members.size() >= 50) return false;  // limit in the club
        if (members.contains(studentId)) return false;  // already member
        members.add(studentId);
        return true;
    }

    // removeMember
    public boolean removeMember(String studentId) {
        return members.remove(studentId);
    }

    public String getName() { return name; }
    public List<String> getMembers() { return members; }
    public double getMembershipFee() { return membershipFee; }
}