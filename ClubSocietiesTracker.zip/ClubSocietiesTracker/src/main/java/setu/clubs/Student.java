package setu.clubs;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private String name;
    private String studentNumber;
    private List<String> clubs;

    public Student(String name, String studentNumber) {
        this.name = name;
        this.studentNumber = studentNumber;
        this.clubs = new ArrayList<>();
    }

    // joinEvent
    public boolean joinEvent(Event event) {
        if (event == null) return false;
        if (event.getMaxStudents() <= event.getCurrentStudents()) {
            return false;
        }
        event.addStudent(this);
        return true;
    }

    public boolean joinClub(String clubName) {
        if (clubName == null || clubName.isEmpty()) return false;
        if (clubs.contains(clubName)) return false;  // in the club
        clubs.add(clubName);
        return true;
    }

    public String getStudentNumber() { return studentNumber; }
    public String getName() { return name; }
    public List<String> getClubs() { return clubs; }
}